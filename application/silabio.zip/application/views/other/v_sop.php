<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<div class="row">
	<div class="col-lg-12">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">SOP Peminjaman dan Pengembalian</h3>
				<br><br>
				<div class="box-body">
					<!--<p>Berikut SOP untuk peminjaman dan pengembalian alat & bahan laboratorium</p>-->
					<p align="center"><iframe src="files/SOP Peminjaman dan Pengembalian Alat dan Bahan Laboratorium.pdf" width="80%" height="500px" align="center"></iframe></p>
				</div>
			</div>
		</div>
	</div>
</div>