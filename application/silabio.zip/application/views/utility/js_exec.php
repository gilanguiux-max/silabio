<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<script type='text/javascript'>
    $(function(){
        <?php echo $js;?>
    });
</script>